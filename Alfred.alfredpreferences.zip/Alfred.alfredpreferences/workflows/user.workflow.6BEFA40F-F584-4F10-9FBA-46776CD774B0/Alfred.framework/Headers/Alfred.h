//
//  Alfred.h
//  Alfred
//
//  Created by Daniel Shannon on 5/25/13.
//  Copyright (c) 2013 Daniel Shannon. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Alfred/AWFeedbackItem.h>
#import <Alfred/AWWorkflow.h>

@interface Alfred : NSObject

@end
